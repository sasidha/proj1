Some related projects (Qlik Sense Visualization Extensions) I have recently created:

{%= related([
  'sense-media-box', 
  'sense-themable-kpi-tile', 
  'sense-on-off-switch', 
  'sense-qr-code',
  'sense-funnel-chart',
  'sense-range-slider',
  'sense-calendar-heatmap',
  'qliksense-extension-tutorial',
  'sense-extension-recipes'
  ]
) %}  
