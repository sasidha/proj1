/********************************************************************************************************\
*                                                                                                        *
*  ./+++++++++++++++++++++/.                      `..                    `..     `..    `..              *
*  +ooooooooooooooo++/ooooo/                      -oo.                   +oo     /oo    -oo-             *
*  +ooooooooooooo`    /oooo/                       ``                    +oo     ```    -oo-             *
*  ++:---:ooooooo.    .oooo/     -:-`        .:-` .::`  `------------`   +oo     -:-    -oo-.-:://:-`    *
*  +/     oooo++o/     /ooo/     -oo/       `oo+  :oo.  `/////////ooo-   +oo     +oo    -oo++/:::/+oo-   * 
*  +/     o:.```-o.    .ooo/      :oo-     `+o+`  :oo.          ./o+-    +oo     +oo    -oo:      `/oo.  *
*  +/     o/     +/     /oo/       /oo.    /oo.   :oo.        ./o+-`     +oo     +oo    -oo-       -oo:  *
*  +/     oo`    -o.    .oo/       `+o+`  -oo-    :oo.      ./o+-`       +oo     +oo    -oo-       .oo:  *
*  +/     oo/     +/     +o/        .oo/ .oo:     :oo.    ./o+-`         +oo     +oo    -oo-       -oo-  *
*  +/     ooo`    -o.    .o/         -oo:+o/      :oo.  ./o+-`           +oo.    +oo    -oo-      .+o+`  *
*  +/     ooo:  `.-o/  `.-o/          :ooo+`      :oo.  /oooooooooooo+   .+oo+:  +oo    .ooo+///++oo/`   *
*  .//////++++//+++++//+++/.           `..        `..    `...........`     `..`  `..      `.-----.`  	 *
*                                                                                                        *
*                                            www.vizlib.com                                              *
*                                                                                                        *
*                          Copyright 2017 © Vizlib Ltd. - All rights reserved                            *
\********************************************************************************************************/


(function() {
  var config, staticUrl;

  config = {
    key: '50lfpgn02s0v0a4i-vwtwpdooblvwfp3nmi-rffpuhw59rm6rms4i-0ech9hhd95yaatt9', 
	extension: 'VizlibTable',
	version: 'auto' // A version can be fixed if changed here, otherwise it will receive the latest version available
  };
  
  var js ='https://vizlib-bouncer.herokuapp.com/get?key='+config.key+'&type=js&extension='+config.extension+'&version='+config.version+'&end';
  var css='https://vizlib-bouncer.herokuapp.com/get?key='+config.key+'&type=css&extension='+config.extension+'&version='+config.version+'&end';
	
  define([
  	js,
	'css!'+css
	],
    function(main) {
      if(typeof(main)=='undefined')
	  {
		return {
			initialProperties: {},
			definition: {},
			snapshot: {
				canTakeSnapshot: false
			},
			paint: function ( $element, layout ) {
				$element.html('<div style="text-align:center; vertical-align:middle; color:red; font-size:24px;"><b><u>Invalid license!</u><br/> Please, contact support@vizlib.com for further assistance.</b></div>');
			}
		}
	  }
	  else {		
	  	return main;
	  }
	 
	  
    });

}).call(this);
