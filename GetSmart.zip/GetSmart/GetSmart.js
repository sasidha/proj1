/*
 * Bootstrap-based responsive mashup
 * @owner Enter you name here (xxx)
 */
/*
 *    Fill in host and port for Qlik engine
 */
var prefix = window.location.pathname.substr( 0, window.location.pathname.toLowerCase().lastIndexOf( "/extensions" ) + 1 );

var config = {
	host: window.location.hostname,
	prefix: prefix,
	port: window.location.port,
	isSecure: window.location.protocol === "https:"
};
//to avoid errors in workbench: you can remove this when you have added an app
var app;
require.config( {
	baseUrl: (config.isSecure ? "https://" : "http://" ) + config.host + (config.port ? ":" + config.port : "" ) + config.prefix + "resources"
} );

require( ["js/qlik"], function ( qlik ) {

	var control = false;
	qlik.setOnError( function ( error ) {
		$( '#popupText' ).append( error.message + "<br>" );
		if ( !control ) {
			control = true;
			$( '#popup' ).delay( 1000 ).fadeIn( 1000 ).delay( 11000 ).fadeOut( 1000 );
		}
	} );

	$( "#closePopup" ).click( function () {
		$( '#popup' ).hide();
	} );
	if ( $( 'ul#qbmlist li' ).length === 0 ) {
		$( '#qbmlist' ).append( "<li><a>No bookmarks available</a></li>" );
	}
	$( "body" ).css( "overflow: hidden;" );
	function AppUi ( app ) {
		var me = this;
		this.app = app;
		app.global.isPersonalMode( function ( reply ) {
			me.isPersonalMode = reply.qReturn;
		} );
		app.getAppLayout( function ( layout ) {
			$( "#title" ).html( layout.qTitle );
			$( "#title" ).attr( "title", "Last reload:" + layout.qLastReloadTime.replace( /T/, ' ' ).replace( /Z/, ' ' ) );
			//TODO: bootstrap tooltip ??
		} );
		app.getList( 'SelectionObject', function ( reply ) {
			$( "[data-qcmd='back']" ).parent().toggleClass( 'disabled', reply.qSelectionObject.qBackCount < 1 );
			$( "[data-qcmd='forward']" ).parent().toggleClass( 'disabled', reply.qSelectionObject.qForwardCount < 1 );
		} );
		app.getList( "BookmarkList", function ( reply ) {
			var str = "";
			reply.qBookmarkList.qItems.forEach( function ( value ) {
				if ( value.qData.title ) {
					str += '<li><a data-id="' + value.qInfo.qId + '">' + value.qData.title + '</a></li>';
				}
			} );
			str += '<li><a data-cmd="create">Create</a></li>';
			$( '#qbmlist' ).html( str ).find( 'a' ).on( 'click', function () {
				var id = $( this ).data( 'id' );
				if ( id ) {
					app.bookmark.apply( id );
				} else {
					var cmd = $( this ).data( 'cmd' );
					if ( cmd === "create" ) {
						$( '#createBmModal' ).modal();
					}
				}
			} );
		} );
		$( "[data-qcmd]" ).on( 'click', function () {
			var $element = $( this );
			switch ( $element.data( 'qcmd' ) ) {
				//app level commands
				case 'clearAll':
					app.clearAll();
					break;
				case 'back':
					app.back();
					break;
				case 'forward':
					app.forward();
					break;
				case 'lockAll':
					app.lockAll();
					break;
				case 'unlockAll':
					app.unlockAll();
					break;
				case 'createBm':
					var title = $( "#bmtitle" ).val(), desc = $( "#bmdesc" ).val();
					app.bookmark.create( title, desc );
					$( '#createBmModal' ).modal( 'hide' );
					break;
			}
		} );
		//function to parse the text submitted by the user on process
		//--------------------------------------------------------------
		$( "[btn-proc]" ).on( 'click', function () {
	  		//get the text that has been input
	  		intxt = " " + document.getElementById("QVinput").value;
			intxt = intxt.toLowerCase();
			//reset variables
			gs_dims = 0;
			gs_meas = 0;
			gs_cols = [];
			gs_chart = '';
			//has a chart type been mentioned
			for (var i = 0; i < objs.length; i++) {
    			if(intxt.indexOf(objs[i])!=-1){
					document.getElementById(objs[i]).checked = true;
					gs_chart = document.getElementById(objs[i]).value;
					break;
				}
			}
			//find the dimensions mentioned
			for (var key in dims) {
    			if(intxt.indexOf(key.toLowerCase())!=-1){
					document.getElementById(dims[key]).checked = true;
					NxDimension = {qLibraryId:dims[key], qType:"dimension"}
					gs_dims += 1;
					gs_cols.push(NxDimension)
				}
			}
			//find the measures mentioned
			for (var key in meas) {
    			if(intxt.indexOf(key.toLowerCase())!=-1){
					document.getElementById(meas[key]).checked = true;
					NxMeasure = {qLibraryId:meas[key], qType:"measure"}
					gs_meas += 1;
					gs_cols.push(NxMeasure)
				}
			}
			//apply selections
			doFilters ( gs_cols )
			//now build the chart
			doChart ( gs_chart, gs_cols, gs_dims, gs_cols )
		});
		//function to build the text and logic from user selections
		//-------------------------------------------------------------
		$('body').on('click', '.lui-checkbox__input', function () {
			//reset variables
			gs_dims = 0;
			gs_meas = 0;
			gs_cols = [];
			gs_chart = '';
			var mTxt = ''
			var mAnd = '';
			var dTxt = ''
			var dAnd = '';
			$("input:checked").each(function () {
				var id = $(this).attr("id");
				var typ = $(this).attr("qtype");
				var nam = $(this).attr("aria-label");
				if(typ=='meas'){
					NxMeasure = {qLibraryId:id, qType:"measure"};
					gs_cols.push(NxMeasure);
					gs_meas +=1;
					mTxt += mAnd + nam + " ";
					mAnd = 'and ';
				}
				if(typ=='dim'){
					NxDimension = {qLibraryId:id, qType:"dimension"}
					gs_cols.push(NxDimension)
					gs_dims +=1;
					dTxt += dAnd + nam + " ";
					dAnd = 'and ';
				}
			});
			//update the text displayed in the text box
			if(mTxt != '' && dTxt != ''){
				mTxt += 'by '
			}
			document.getElementById("QVinput").value = 'Show ' + mTxt + dTxt;
			//apply selections
			doFilters ( document.getElementById("QVinput").value, gs_cols )
			//now build the chart
			doChart ( gs_chart, gs_cols, gs_dims, gs_cols )
		});
		//function to work out possible selections
		//-------------------------------------------------------------
		function doFilters ( gs_cols ) {
			sText = document.getElementById("QVinput").value;
			//strip the chosen dimension and measure names from the text
			$("input:checked").each(function () {
				var nam = $(this).attr("aria-label");
				sText = sText.replace(nam, '')
			});
			//alert(sText);
		}

	}

	//function to display the chart based on user inputs
	//-------------------------------------------------------------
	function doChart ( gs_chart, gs_cols ) {
		if (gs_chart==''){
		  //KPI object if no dimensions chosen
		  if (gs_dims==0){
			document.getElementById(' kpi').checked = true;
			gs_chart = 'kpi'
		  }
		  //Scatter if 1 dimension and 2 or 3 measures
		  else if(gs_dims==1 && (gs_meas==2 || gs_meas==3) ){
			document.getElementById(' scatter').checked = true;
			gs_chart = 'scatterplot'
		  }
		  //Bar chart if 1 measure and 1 or 2 dimensions
		  else if(gs_meas==1 && (gs_dims==1 || gs_dims==2) ){
			document.getElementById(' bar').checked = true;
			gs_chart = 'barchart'
		  }
		  else{
			document.getElementById(' table').checked = true;
			gs_chart = 'table'
		  }
		}
		//now display the chart for the user
		console.log(gs_cols);
		console.log(gs_chart);

		var obj = {};
		if (gs_chart != 'linechart') {
			obj['auto'] = false;
			obj['mode'] = "byMeasure";
			obj['measureScheme'] = "sc";
		}



		app.visualization.create(
		  gs_chart,
		  gs_cols,
			{
					  		 "orientation": "horizontal",
					  		  "lineType": "area",
					  		 "dataPoint" : {"showLabels": true},
							 "color": obj



		  	}
,
							  {"title":"On the fly chart"}




		).then(function(vis){
		  vis.show("QV01");
		});
	}

	//function to fetch the dimensions and measures for the chosen app
	//-------------------------------------------------------------
	function doApp (app_id){
		//open app using the ID
		app = qlik.openApp(app_id, config);

		//display the list of measures from the master library
		app.getList("MeasureList", function(reply){
			//alert(JSON.stringify(reply))
			$.each(reply.qMeasureList.qItems, function(key, value) {
				mHTML += mItem.replace(/gs_label/g, value.qMeta.title).replace(/gs_id/g, value.qInfo.qId)
				meas[value.qMeta.title] = value.qInfo.qId;
			});
			document.getElementById("measList").innerHTML = mHTML;
		});

		//display the list of dimensions from the master library
		app.getList("DimensionList", function(reply){
			//alert(JSON.stringify(reply))
			$.each(reply.qDimensionList.qItems, function(key, value) {
				dHTML += dItem.replace(/gs_label/g, value.qMeta.title).replace(/gs_id/g, value.qInfo.qId)
				dims[value.qMeta.title] = value.qInfo.qId;
			});
			document.getElementById("dimList").innerHTML = dHTML;
		});
	}

	var app = '';
	//setup objects required to apply selections
	var gs_dims = 0;
	var gs_meas = 0;
	var gs_cols = [];
	var gs_chart = '';
	//objects required to render
	var dims = {}
	var meas = {}
	var objs = [
	  " kpi",
	  " bar",
	  " line",
	  " scatter",
	  " table",
	  " treemap"
	];

	//setup objects required to render the dimension and measure lists
	//------------------------------------------------------------------
	var mHTML = '<div style="font-weight:bold; font-size:120%; padding: 20px 0px 10px 0px;">Measures</div>'
	var dHTML = '<div style="font-weight:bold; font-size:120%; padding: 20px 0px 10px 0px;">Dimensions</div>'
	var mItem =  ''
	mItem += '<label class="lui-checkbox">'
	mItem += ' <input qtype="meas" class="lui-checkbox__input" aria-label="gs_label" type="checkbox" value="gs_id" id="gs_id">'
	mItem += ' <div class="lui-checkbox__check-wrap">'
	mItem += '  <span class="lui-checkbox__check"></span>'
	mItem += '  <span class="lui-checkbox__check-text">gs_label</span>'
	mItem += ' </div>'
	mItem += '</label>'
	var dItem =  ''
	dItem += '<label class="lui-checkbox">'
	dItem += ' <input qtype="dim" class="lui-checkbox__input" aria-label="gs_label" type="checkbox" value"gs_id" id="gs_id">'
	dItem += ' <div class="lui-checkbox__check-wrap">'
	dItem += '  <span class="lui-checkbox__check"></span>'
	dItem += '  <span class="lui-checkbox__check-text">gs_label</span>'
	dItem += ' </div>'
	dItem += '</label>'

	//get the list of applications for the user to select from
	//-------------------------------------------------------------
	qlik.getAppList(function(list){
		var sel = document.getElementById("appSelect");
		//var aHTML = '<select style="width:18%" class="lui-select" >';
		//aHTML += '<option value="" selected>Select an application</option>';
		list.forEach(function(value) {
			//aHTML += '<option value="' + value.qDocId + '">' + value.qDocName + '</option>';
			var opt = document.createElement('option');
    		opt.value = value.qDocId;
    		opt.innerHTML = value.qDocName;
    		sel.appendChild(opt);
		});
	}, config);

	//Bind actions to the app selector drop down to initialise
	//------------------------------------------------------------
	$( "[sel-app]" ).on( 'change', function () {
		dims = {};
		meas = {};
		gs_dims = 0;
		gs_meas = 0;
		gs_cols = [];
		gs_chart = '';
		document.getElementById("QVinput").value = '';
		document.getElementById("QV01").innerHTML = '';
		mHTML = '<div style="font-weight:bold; font-size:120%; padding: 20px 0px 10px 0px;">Measures</div>'
		dHTML = '<div style="font-weight:bold; font-size:120%; padding: 20px 0px 10px 0px;">Dimensions</div>'
		doApp(document.getElementById("appSelect").value)
		new AppUi( app );
	});


} );
